<?php

defined('BASEPATH') OR exit('Ille');
/**
 * 
 */
class ChapterC extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("Instructor/ChapterM","chpm");
	}
	
	public function addChapter($courseID)
	{
		$name = $this->input->post('txtchapter');
		$data = array(
			'courseID'=>$courseID,
			'chapterName'=>$name
		);
		

		$this->chpm->addChapter($data);
		$chpID=$this->db->insert_id();

		$data1=array(
			'chapterID'=>$chpID,
			'topicName'=>$this->input->post('txttopic'),
			'description'=>$this->input->post('txtdescription'),
			'videoURL'=>''
		);

		$img=$this->input->post('img');
		$image_array_1=explode(";",$img);
		$image_array_2=explode(",",$image_array_1[1]);
		$img1=base64_decode($image_array_2[1]);
		$imagename=$this->input->post('txttopic').".mp4";
		file_put_contents("upload/".$imagename,$img1);

		$data1['videoURL']=$imagename;
		// echo "<pre>";
		// print_r($data);
		// print_r($data1);
		// die();
		$this->chpm->addTopics($data1);
	
			}

	
}
?>