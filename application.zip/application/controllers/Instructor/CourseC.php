<?php

defined('BASEPATH') OR exit('Ille');
/**
 * 
 */
class CourseC extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("Instructor/CourseM","cm");
	}

	public function index()
	{
		$course = $this->cm->fetchAllCourse();
		$res=$this->cm->fillSubject();
		$data = array(
			"courseData" => $course,
			"subjectData"=>$res
		);
		$this->load->view("Instructor/CourseView",$data);
	}

	
	public function searchCourse()
	{
		$name = $this->input->post('txtsearch');
		$x = $this->cm->searchCourse($name);
		$data = array(
			"courseData"=>$x
		);
		$this->load->view("Instructor/CourseView",$data);
	}

	public function courseDetails($courseID)
	{
		$res1=$this->cm->fetchReview($courseID);
		$res2=$this->cm->fetchChapter($courseID);
		// echo $this->db->last_query();
		$res=$this->cm->fetchviewCourse($courseID);
		$data=array(
			'courseID'=>$courseID,
			'courseDetails'=>$res,
			'chapterData'=>$res2,
			'coursedescription'=>$res[0]->description,
			'reviewdata'=>$res1
		);
		/*echo "<pre>";
		print_r($data);
		die();*/
		$this->load->view("Instructor/viewmoreCourse",$data);	
	}

	public function addCourse()
	{
		$data = array(
			'courseName' => $this->input->post('txtcourse'),
			'userID'=>$this->session->userID,
			'description' => $this->input->post('description'),
			'image' => "",
			'price' => $this->input->post('price'),
			'subjectID' => $this->input->post('listSubject')
		);

		$img=$this->input->post('img');
		$image_array_1=explode(";",$img);
		$image_array_2=explode(",",$image_array_1[1]);
		$img1=base64_decode($image_array_2[1]);
		$imagename=$this->input->post('txtcourse').".jpg";
		file_put_contents("upload/course/".$imagename,$img1);

		$data['image']=$imagename;
		$this->cm->addCourse($data);
		$this->load->view('Instructor/CourseView',$data);
		redirect('Instructor/CourseC/');			
	}
	
}
?>