<?php

defined('BASEPATH') OR exit('Ille');
/**
 * 
 */
class CartC extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model("User/CartM","cam");
		if(!$this->session->userID)
		{
			redirect("User/LoginC");
		}
	}

	public function index($courseid=null)
	{
		$data=array(
			"userID"=>$this->session->userID,
			"courseID"=>$courseid
		);
		// print_r($data);
		// die();
		$this->cam->insertCart($data);
	}

	public function viewCart($val=null)	
	{
		if($val==1)
		{
			?>
			<script type="text/javascript">
				alert("Sorry,Your Payment Failed");
			</script>
			<?php
		}
		$id=$this->session->userID;
		$res=$this->cam->showCart($id);
		$data=array(
			"cartData"=>$res
		);
		$this->load->view("User/cart",$data);
	}

	public function deleteCart($id)
	{
		$res=$this->cam->delCart($id);
		redirect("User/CartC/viewCart");
	}
}
?>
