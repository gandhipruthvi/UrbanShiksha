<!-- jQuery -->
<script src="iresources/plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="iresources/plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- FastClick -->
<script src="iresources/plugins/fastclick/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="iresources/dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="iresources/dist/js/demo.js"></script>

<script src="assets/plugins/dropzone/dropzone.js"></script> <!-- Dropzone Plugin Js -->