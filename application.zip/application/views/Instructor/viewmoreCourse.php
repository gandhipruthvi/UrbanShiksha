<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>AdminLTE 3 | User Profile</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <base href="<?=base_url();?>">



  <!-- favicon icon -->
  <link rel="shortcut icon" href="images/Favicon.ico">
<link href="assets/plugins/dropzone/dropzone.css" rel="stylesheet">
  <!-- links -->

  <?php require_once("link.php")?>
</style>
<style type="text/css">
  input[type=text], select {
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
}

.modal-header {
  padding: 2px 16px;
  background-color: #6495ED;
  color: white;
}
</style>
</head>
<body class="hold-transition sidebar-mini">
  <div class="wrapper">

    <!-- navBar -->
    <?php require_once("navBar.php")?>

    <!-- mainSideBar -->
    <?php require_once("mainSideBar.php")?> 

    <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
      <!-- Content Header (Page header) -->
      <section class="content-header">
        <div class="container-fluid">
          <div class="row mb-2">
            <div class="col-sm-6">
              <h1>Profile</h1>
            </div>
            <div class="col-sm-6">
              <ol class="breadcrumb float-sm-right">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active">User Profile</li>
              </ol>
            </div>
          </div>
        </div><!-- /.container-fluid -->
      </section>

      <!-- Main content -->
      <section class="content">
        <div class="container-fluid">
          <div class="row">
            <div class="col-md-3">

              <!-- Profile Image -->
              <div class="card card-primary card-outline">
                <div class="card-body box-profile">
                  <?php
                  foreach ($courseDetails as $key) {
                    ?>
                    <div class="text-center">
                      <img class="profile-user-img img-fluid img-circle"
                      src="upload/course/<?= $key->image?>"
                      alt="User profile picture" style="height: 150px; width: 200px">
                    </div>

                    <p class="text-muted text-center"><?=$key->courseName?></p>

                    <ul class="list-group list-group-unbordered mb-3">
                      <li class="list-group-item">
                        <b>Price</b> <a class="float-right"><?=$key->price?></a>
                      </li>
                      <li class="list-group-item">
                        <b>Subject</b> <a class="float-right"><?=$key->subjectName?></a>
                      </li>
                    </ul>
                    <?php
                  }
                  ?>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              <!-- About Me Box -->
              <div class="card card-primary">
                <div class="card-header">
                  <h3 class="card-title">Description</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">

                  <p class="text-muted">
                    <?=$coursedescription?>
                  </p>
                  <hr>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
            </div>
            <!-- /.col -->
            <div class="col-md-9">
              <div class="card">
                <div class="card-header p-2">
                  <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#activity" data-toggle="tab">Reviews</a></li>
                    <li class="nav-item"><a class="nav-link" href="#timeline" data-toggle="tab">Syllabus</a></li>
                    <li class="nav-item"><a class="nav-link" href="#settings" data-toggle="tab">Settings</a></li>
                  </ul>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content">

                    <div class="tab-pane" id="activity">
                     <div class="reviews">
                      <div class="reviews-view">
                        <h4>Reviews List</h4>
                        <div class="reviews-slide">
                          <?php
                          foreach ($reviewdata as $key1) { 
                            ?>
                            <div class="row">
                              <div class="col-md-2">
                                <div class="img-responsive img-circle" style="text-align:center"><img src="<?= base_url("upload/$key1->image")?>" style="width:80px;height:80px;border-radius:50%"></div>
                              </div>
                              <div class="col-md-10">
                                <span style="color:RED"><?=$key1->userName?></span><br>
                                <?php 
                                for($i=1;$i<=5;$i++)
                                {
                                  if($key1->stars>=$i)
                                  {
                                    ?>
                                    <i class="fill fa fa-star" style="color:orange;"></i>
                                    <?php
                                  }
                                  else
                                  {
                                    ?>
                                    <i class="fa fa-star-o" style="color:orange;"></i>
                                    <?php
                                  }
                                }
                                ?>
                                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you </p>
                              </div>
                            </div>
                            <?php
                          }
                          ?>
                        </div>
                      </div>
                    </div>
                  </div>


                  <!-- /.tab-pane -->
                  <div class="tab-pane active" id="timeline">
                    <!-- The timeline -->
                    <div class="syllabus">
    <div class="row">
        <div class="col-md-9"><h4>Syllabus</h4></div>
    <div class="col-md-3"><a href="#" class="btn btn-primary btn-block" data-toggle="modal" data-target="#myModal" style="height: 40px;width:150px"><b>Add New Chapter</b></a></div>

  </div>

          <!-- <div>
             <a href="#" class="addCourse" data-toggle="modal" data-target="#myModal">Add New Course</a>
          </div> -->
    <div class="syllabus-box">
      <?php
        $cnt=0;
        foreach ($chapterData as $key2) {
                    $cnt++;
                  ?>
            <div class="syllabus-title"><b>Chapter<?php echo $cnt; echo ":-";echo $key2->chapterName?></b></div>
        <div class="syllabus-view first row">
            <div class="main-point active col-md-9">Lorem Ipsum is simply dummy text of the printing and typesetting</div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">vedio : Lorem ipsum dolor sit amet. <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="course-lessons.html">Document : semper dolor quis lectus facilisis laoreet. <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="quiz-intro.html">Quizzes : auctor quam quis commodo feugiat. <span class="hover-text">upgrade now<i class="fa fa-angle-right"></i><i class="fa fa-angle-right"></i></span></a></li>
                    <li class="no-link">There are many variations of passages of Lorem Ipsum available, </li>
                </ul>
            </div>
        </div>

        
        <?php
          }
      ?>
    </div>
</div>
                  </div>
                  <!-- /.tab-pane -->

                  <div class="tab-pane" id="settings">
                    <form class="form-horizontal">
                      <div class="form-group">
                        <label for="inputName" class="col-sm-2 control-label">Name</label>

                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputEmail" class="col-sm-2 control-label">Email</label>

                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputName2" class="col-sm-2 control-label">Name</label>

                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputName2" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputExperience" class="col-sm-2 control-label">Experience</label>

                        <div class="col-sm-10">
                          <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                        <label for="inputSkills" class="col-sm-2 control-label">Skills</label>

                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <div class="checkbox">
                            <label>
                              <input type="checkbox"> I agree to the <a href="#">terms and conditions</a>
                            </label>
                          </div>
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-danger">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <!-- /.tab-pane -->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->

  <!-- footer -->
  <?php require_once("footer.php")?>


    <!-- Modal -->
    <!-- <div id="myModal" class="modal fade" role="dialog">
      <div class="modal-dialog">


        <div class="modal-content">
          <form role="form" method="post" enctype="multipart/form-data" action="<?= site_url("Instructor/ChapterC/addChapter/$courseID")?>">
          <div class="modal-header">
            <h4 class="modal-title">Chapter</h4>
            <button type="button" class="close" data-dismiss="modal">&times;</button>
          </div>
          <div class="modal-body">
            
                <div class="card-body">
                  <div class="form-group">
                    <input type="text" class="form-control" name="txtchapter" placeholder="Enter Chapter...">
                  </div>
               
                </div>

          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-primary" style="background-color: #6495ED;">Submit</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
          </div>
          </form>
        </div>

      </div>
    </div> -->


<!-- Modal -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
              <h4 class="modal-title" id="myModalLabel">Chapter</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="col-md-9">
              <div class="card" style="width: 28rem;">
                <div class="card-header p-2">
                  <ul class="nav nav-pills">
                    <li class="nav-item"><a class="nav-link active" href="#addchapter" data-toggle="tab">Add</a></li>
                    <li class="nav-item"><a class="nav-link" href="#editchapter" data-toggle="tab">Edit</a></li>
                  </ul>
                </div><!-- /.card-header -->
                <div class="card-body">
                  <div class="tab-content">
                  <!-- /.tab-pane -->
                  <div class="tab-pane active" id="addchapter">
                    <form class="form-horizontal" method="post" enctype="multipart/form-data" action="<?= site_url("Instructor/ChapterC/addChapter/$courseID")?>">
                      <div class="form-group">

                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="txtchapter" placeholder="Enter Chapter...">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-10">
                          <input type="text" class="form-control" name="txttopic" placeholder="Enter Topic Name...">
                        </div>
                      </div>
                      <div class="form-group">
                        <div class="col-sm-10">
                          <textarea class="form-control" name="txtdescription" placeholder="Enter Description..." style="height:100px;width:270px"></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                      <div class="dropzone" id="myDropzone" style="height:200px">
                        <div class="dz-default dz-message">
                          <span>Upload Video</span>
                        </div> 
                        <input type="hidden" name="img" id="img">         
                      </div>
                    </div>
                      <div class="form-group">
                        <div class="col-sm-offset-2 col-sm-10">
                          <button type="submit" class="btn btn-success">Submit</button>
                        </div>
                      </div>
                    </form>
                  </div>
                  <!-- /.tab-pane -->
                  <!--/.tab-pane-->
                   <div class="tab-pane" id="editchapter">
                    <!-- The timeline -->
                    <div class="syllabus">
                      <div><h4>Syllabus</h4></div>

          <!-- <div>
             <a href="#" class="addCourse" data-toggle="modal" data-target="#myModal">Add New Course</a>
          </div> -->
    <div class="syllabus-box">
      <?php
        $cnt=0;
        foreach ($chapterData as $key2) {
                    $cnt++;
                  ?>
            <div class="syllabus-title"><b>Chapter<?php echo $cnt; echo ":-";echo $key2->chapterName?></b></div>
        <div class="syllabus-view first row">
            <div class="main-point active col-md-9">Lorem Ipsum is simply dummy text of the printing and typesetting</div>
        </div>

        
        <?php
          }
      ?>
    </div>
</div>
                  </div>
                  <!--#tab-pan-->
                </div>
                <!-- /.tab-content -->
              </div><!-- /.card-body -->
            </div>
            <!-- /.nav-tabs-custom -->
          </div>


            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->
<!-- script -->

<?php require_once("script.php")?>
</body>
</html>
<script type="text/javascript">
  Dropzone.autoDiscover = false;
  var base64 = '';
  $("#myDropzone").dropzone({
    url: "<?= base_url("upload")?>",       
    addRemoveLinks: true,
    maxFiles: 1,
    maxFileSize: 1,
    init: function() {
      this.on("addedfile", function (file) {
        var reader = new FileReader();
        reader.onload = function(event) {               
          var base64String = event.target.result;
          $("#img").val(base64String);
          handlePictureDropUpload(base64String ,fileName );
        };
        reader.readAsDataURL(file);
      });
    },
  });
</script>







