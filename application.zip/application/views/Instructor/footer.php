<footer class="main-footer">
	<div class="float-right d-none d-sm-block">
		<b></b> 3.0.0-alpha
	</div>
	<strong></strong> All rights
	reserved.
</footer>