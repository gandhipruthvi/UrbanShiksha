<!DOCTYPE html>
<html>

<!-- Mirrored from thememakker.com/templates/swift/university/add-professors.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Apr 2019 11:10:10 GMT -->
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=Edge">
<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
<base href="<?=base_url()?>">
<title>Admin</title>
<link rel="icon" href="favicon.ico" type="image/x-icon">
<!-- Favicon-->
<link href="assets/plugins/bootstrap/css/bootstrap.min.css" rel="stylesheet" />
<link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet" type="text/css">
<!-- Dropzone Css -->
<link href="assets/plugins/dropzone/dropzone.css" rel="stylesheet">
<!-- Bootstrap Material Datetime Picker Css -->
<link href="assets/plugins/bootstrap-material-datetimepicker/css/bootstrap-material-datetimepicker.css" rel="stylesheet" />
<!-- Wait Me Css -->
<link href="assets/plugins/waitme/waitMe.css" rel="stylesheet" />
<link href="assets/css/main.css" rel="stylesheet">
<!-- Custom Css -->


<link href="assets/css/themes/all-themes.css" rel="stylesheet" />
</head>

<body class="theme-blush">
<!-- Page Loader -->
<?php include_once("pageLoader.php");?>
<!-- #END# Page Loader --> 

<!-- Overlay For Sidebars -->
<div class="overlay"></div>
<!-- #END# Overlay For Sidebars --> 

<!-- Morphing Search  -->
<?php include_once("morphingSearch.php");?>    
<!-- /morphsearch-content --> 

<!-- Top Bar -->
<?php include_once("topBar.php");?>
<!-- #Top Bar -->

<!--Side menu and right menu -->
<?php include_once("sideMenuRightMenu.php");?>
<!--Side menu and right menu -->

<!-- main content -->
<section class="content">
    <div class="container-fluid">
        <div class="block-header">
            <h2>Add Admin</h2>
            <small class="text-muted">Welcome to Add Page</small>
            <form method="post" enctype="multipart/form-data" action="<?=site_url('Admin/AdminC/addAdmin')?>">
            <div class="row clearfix">           
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" class="form-control" placeholder="Admin Name" name="txtanm">
                        </div>
                    </div>
                </div>
            </div>

            <div class="row clearfix">           
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" class="form-control" placeholder="Email" name="txtemail">
                        </div>
                    </div>
                </div>
            </div>

            <?php
                if(!isset($adminInfo->adminID))
                {
            ?>
            <div class="row clearfix" id="p1">           
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="password" class="form-control" placeholder="Password" name="txtpass">
                        </div>
                    </div>
                </div>
            </div>

            <div class="dropzone" id="myDropzone">
                <div class="dz-default dz-message">
                    <span>Drop files here to upload</span>
                </div> 
                <input type="hidden" name="img" id="img">         
            </div>

            <?php
                }
            ?>   

            <div class="row clearfix">           
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" class="form-control" placeholder="User Name" name="txtusnm">
                        </div>
                    </div>
                </div>
            </div>   

<!--             <div class="row clearfix">
                <div class="col-lg-12 col-md-12 col-sm-12">
                    <div class="dz-message">
                            <div class="drag-icon-cph"> <i class="material-icons">touch_app</i> </div>
                            <h3>Click to upload.</h3>
                            </div>
                         <div class="fallback">
                            <input type="file" name="fup">
                        </div>
                </div>
            </div>
 -->
            <div class="row clearfix">           
                <div class="col-md-6 col-sm-12">
                    <div class="form-group">
                        <div class="form-line">
                            <input type="text" class="form-control" placeholder="Contact No" name="txtcno">
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-sm-12">
                <input type="submit" class="btn btn-raised g-bg-blush2" value="Submit">
            </div>

                </form>
        </div>
    </div>
</section>
<!-- main content -->

<div class="color-bg"></div>

<!-- Jquery Core Js --> 
<script src="assets/bundles/libscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="assets/bundles/vendorscripts.bundle.js"></script> <!-- Lib Scripts Plugin Js -->
<script src="assets/bundles/morphingsearchscripts.bundle.js"></script> <!-- Main top morphing search --> 


<script src="assets/plugins/autosize/autosize.js"></script> <!-- Autosize Plugin Js --> 
<script src="assets/plugins/momentjs/moment.js"></script> <!-- Moment Plugin Js --> 
<script src="assets/plugins/dropzone/dropzone.js"></script> <!-- Dropzone Plugin Js -->
<!-- Bootstrap Material Datetime Picker Plugin Js --> 
<script src="assets/plugins/bootstrap-material-datetimepicker/js/bootstrap-material-datetimepicker.js"></script> 

<script src="assets/bundles/mainscripts.bundle.js"></script><!-- Custom Js --> 
<script src="assets/js/pages/forms/basic-form-elements.js"></script>
</body>

<!-- Mirrored from thememakker.com/templates/swift/university/add-professors.html by HTTrack Website Copier/3.x [XR&CO'2014], Sat, 13 Apr 2019 11:10:13 GMT -->
</html>
<script type="text/javascript">
    Dropzone.autoDiscover = false;
    var base64 = '';
    $("#myDropzone").dropzone({
        url: "<?= base_url("upload")?>",       
        addRemoveLinks: true,
        maxFiles: 1,
        maxFileSize: 1,
        init: function() {
            this.on("addedfile", function (file) {
                var reader = new FileReader();
                reader.onload = function(event) {
                    // event.target.result contains base64 encoded image                    
                    var base64String = event.target.result;

                    $("#img").val(base64String);
                    handlePictureDropUpload(base64String ,fileName );
                };
                reader.readAsDataURL(file);
            });
        },
    });
</script>