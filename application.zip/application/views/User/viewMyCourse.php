    <!DOCTYPE html>
    <html lang="en">
    <head>
        <!-- Meta information -->
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
        <base href="<?=base_url();?>">

        <!-- Title -->
        <title>Academy</title>
        <style type="text/css">
    /*        .fl::first-letter {
          font-size: 200%;
          color: #8A2BE2;
          }*/

          body {margin:2rem;}

          .modal-dialog {
              max-width: 800px;
              margin: 30px auto;
          }



          .modal-body {
              position:relative;
              padding:0px;
          }
          .close {
              position:absolute;
              right:-30px;
              top:0;
              z-index:999;
              font-size:2rem;
              font-weight: normal;
              color:#fff;
              opacity:1;
          }

/*          [data-letters]:before {
              content:attr(data-letters);
              display:inline-block;
              font-size:1em;
              width:1.5em;
              height:1.5em;
              line-height:2.5em;
              text-align:center;
              border-radius:50%;
              background:plum;
              vertical-align:middle;
              margin-right:1em;
              color:white;
              }*/

              .circle{
                  position:relative;
                  width:50%;
                  padding-bottom:50%;
                  background:gold;
                  border-radius:50%;
              }
              .circle p{
                  position:absolute;
                  top:50%; left:50%;
                  transform: translate(-50%, -50%);
                  margin:0;
                  font-style: normal;
              }

              /* Popover */
              .popover {
                border: 2px dotted red;
                width:600px;
            }
        </style>
        <!-- favicon icon -->
        <link rel="shortcut icon" href="images/Favicon.ico">

        <!-- CSS Stylesheet -->
        <!--Link Page-->
        <?php include_once("link.php");?>
        <!--#Link Page-->

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
    <script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<script type="text/javascript">
    cart0=<?= $cartdata?>;
    enroll0=<?= $enrollData?>;
</script>
</head>

<body>
    <div class="wapper">
        <!--quckNav-->
        <?php include_once("quckNav.php");?>
        <!--#quckNav-->

        <!--Header-->
        <?php include_once("header.php");?>
        <!--#Header-->
        <section class="banner inner-page">
            <div class="banner-img"><img src="images/banner/courses-banner.jpg" alt=""></div>
            <div class="page-title">    
                <div class="container">
                    <h1>courses details</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
            <div class="container">
                <ul>
                    <li><a href="<?= site_url('User/HomeC/')?>">Home</a></li>
                    <li><a href="<?= site_url('User/CourseC/')?>">All courses</a></li>
                    <li><a>courses details</a></li>
                </ul>
            </div>
        </section>
        <div class="course-details">
            <div class="container">
                <h2><?=$coursedata->courseName?></h2>
                <div class="course-details-main">
                    <div class="course-img">
                        <img src="<?= base_url("upload/$coursedata->image")?>" class="img-fluid" style="height:400px;width:1250px;">
                    </div>
                    <div class="course-info">
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file"></i></div>
                            <p>17 Lessons</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-exclamation"></i></div>
                            <p>7 Quizzes</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file-text-o"></i></div>
                            <p>13 Documents</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-video-camera"></i></div>
                            <p>9 vedio</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-mortar-board"></i></div>
                            <p>1719 Students</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="course-instructorInfo">
                                <div class="info-slide"><i class="fa fa-user-secret"></i><?=$coursedata->userName;?></div>
                                <!--  <div class="info-slide"><i class="fa fa-calendar"></i>16-09-2016 - 15-08-2018 </div> -->
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="btn-row">
                                <div class="col-md-3"></div>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="info">
                    <h4>Course Overview</h4>
    <!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
        <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. </p> -->
        <p><?=$coursedata->description?></p>
    </div>
    <div class="instructors">
        <h4>Meet The Instructors</h4>
        <div class="row">
            <div class="col-sm-4">
                <div class="instructors-box">
                    <div class="img"><img src="images/user-img/img6.jpg" alt=""></div>
                    <div class="name">variations passages</div>
                    <div class="designation">reasonable</div>
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                    <div class="link"><a href="instructor-profile.html">More Info</a></div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="instructors-box">
                    <div class="img"><img src="images/user-img/img7.jpg" alt=""></div>
                    <div class="name">variations passages</div>
                    <div class="designation">reasonable</div>
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                    <div class="link"><a href="instructor-profile.html">More Info</a></div>
                </div>
            </div>
            <div class="col-sm-4">
                <div class="instructors-box">
                    <div class="img"><img src="images/user-img/img8.jpg" alt=""></div>
                    <div class="name">variations passages</div>
                    <div class="designation">reasonable</div>
                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                    <div class="link"><a href="instructor-profile.html">More Info</a></div>
                </div>
            </div>

        </div>
    </div>




    <div>

        <!-- Nav tabs -->
        <ul class="nav nav-tabs" role="tablist">
            <li role="presentation" class="active" style="padding-right:0px;padding-left:0px;"><a href="#home" aria-controls="home" role="tab" data-toggle="tab" style="padding:10px;">Syllabus</a></li>
            <li role="presentation" style="padding-right:0px;padding-left: 0px;"><a href="#profile" aria-controls="profile" role="tab" data-toggle="tab" style="padding:10px;">Questions</a></li>
            <li role="presentation" style="padding-right:0px;padding-left: 0px;"><a href="#messages" aria-controls="messages" role="tab" data-toggle="tab" style="padding:10px;">Reviews</a></li>
            <li role="presentation" style="padding-right:0px;padding-left: 0px;"><a href="#settings" aria-controls="settings" role="tab" data-toggle="tab" style="padding:10px;">Settings</a></li>
        </ul>

        <!-- Tab panes -->
        <div class="tab-content">
            <div role="tabpanel" class="tab-pane active" id="home">
                <!-- syllabus -->
                <pre style="background-color: white;border-color: white;"></pre>
                <div class="syllabus">
                    <h4>Syllabus</h4>
                    <?php
                    $cnt = 1;
                    foreach ($chapterData as $key) 
                    {
                        ?>
                        <div class="syllabus-box">
                            <div class="syllabus-title"></div>
                            <div class="syllabus-view first">
                                <div class="main-point active"><?=$cnt?> : <?=$key->chapterName?></div>
                                <?php
                                foreach ($key->tpID as $key0) 
                                {
                                    ?>
                                    <div class="point-list">
                                        <ul>
                                            <li><a class="video-btn" data-toggle="modal" data-src="<?=$key0->videoURL?>" data-target="#myModal"> Video : Click here <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i></span></a></li>
                                            <li><a href="course-lessons.html"> <?=$key0->description?> <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i></span></a></li>
                                        </ul>
                                    </div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                        <?php
                        $cnt++;
                    }
                    ?>
                </div>

            </div>
            <div role="tabpanel" class="tab-pane" id="profile">
                <!-- question -->
                <pre style="background-color: white;border-color: white;"></pre>

                <div class="question">
                    <h4>Ask Question</h4>
                    <div>
                        <input type="button" style="background-color: #008CBA;border: none;color: white;padding: 10px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer;" value="Ask Question" id="asked">
                    </div>
                    <div class="ask-question" style="visibility: hidden;display: none;">
                        <div class="row">
                          <div class="info-slide col-md-2">
                             <p><span>Ask Question :</span></p>
                         </div>
                         <div class="input-box col-md-10">
                             <input type="text" style="width:500px;height:150px;" class="form-control" id="txtQuestion">
                         </div>
                     </div>
                     <pre style="background-color: white;border-color: white;"></pre>
                     <div class="row">
                        <div class="col-md-2"></div>
                        <div class="col-md-10">
                          <input type="button" style="background-color: #008CBA;border: none;color: white;padding: 10px 32px;text-align: center;text-decoration: none;display: inline-block;font-size: 16px;margin: 4px 2px;cursor: pointer;" value="Ask" id="askButton" onclick="myQue(<?=$coursedata->courseID?>)">
                      </div>
                  </div>
              </div>
          </div>
          <pre style="background-color: white;border-color: white;"></pre>

          <div class="questions">
            <div class="questions-view">
                <h4>Questions List</h4>
                <div class="questions-slide"></div>
                <?php
                $q = 0;
                foreach ($questions as $key)
                {
                    ?>


                    <div class="container"> 

                        <div class="panel-group" id="accordion">
                            <div class="panel panel-default">
                              <div class="panel-heading" style="background-color: white;">
                                <h4 class="row" style="position : static;">
                                    <div class="col-md-11">
                                      <a data-toggle="collapse" data-parent="#accordion" href="#collapse1<?=$key->questionID?>"><?=$key->question?></a>
                                  </div>
                                  <div class="col-md-1">
                                      <div class="circle popper" data-toggle="popover">
                                          <p><?= substr($key->userName, 0,1)?></p>
                                      </div>
                                      <div class="popper-content hide"><p><img src="<?=base_url();?>upload/<?=$key->image?>"></p><p>Name : <?=$key->userName?></p></div>
                                  </div>  
                              </h4>
                          </div>
                          <div id="collapse1<?=$key->questionID?>" class="panel-collapse collapse">
                            <div class="panel-body">
                                <?php
                                foreach ($key->answer as $key0)
                                {
                                    ?>
                                    <div><?=$key0->answer?></div>
                                    <?php
                                }
                                ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php
        }
        ?>
    </div>
</div>
<!-- end question -->
</div>
<div role="tabpanel" class="tab-pane" id="messages">

    <div class="reviews">
        <div class="reviews-view">
            <h4>Reviews List</h4>
            <div class="reviews-slide">
                <?php
                foreach ($reviewdata as $key) { 
                    ?>
                    <div class="row">
                        <div class="col-md-2">
                            <div class="img-responsive img-circle" style="text-align:center"><img src="<?= base_url("upload/$key->image")?>" style="width:80px;height:80px;border-radius:50%"></div>
                        </div>
                        <div class="col-md-10">
                            <span style="color:RED"><?=$key->userName?></span><br>
                            <?php 
                            for($i=1;$i<=5;$i++)
                            {
                                if($key->stars>=$i)
                                {
                                    ?>
                                    <i class="fill fa fa-star" style="color:orange;"></i>
                                    <?php
                                }
                                else
                                {
                                    ?>
                                    <i class="fa fa-star-o" style="color:orange;"></i>
                                    <?php
                                }
                            }
                            ?>



                            <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you </p>
                        </div>
                    </div>
                    <?php
                }
                ?>

            </div>

        </div>
    </div>
</div>
<div role="tabpanel" class="tab-pane" id="settings">...</div>
</div>

</div>


</div>
</div>
<!--Footer Page-->
<?php include_once("footer.php");?>
<!--#Footer Page-->
</div>
    <!-- Bootstrap core JavaScript
        ================================================== -->
        <!-- Placed at the end of the document so the pages load faster -->

        <!--Script Page-->
        <?php include_once("script.php");?>
        <!--#Script Page-->

        <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">


                  <div class="modal-body">

                   <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                      <span aria-hidden="true">&times;</span>
                  </button>        
                  <!-- 16:9 aspect ratio -->
                  <div class="embed-responsive embed-responsive-16by9">
                      <iframe class="embed-responsive-item" src="" id="video"  allowscriptaccess="always" allow="autoplay"></iframe>
                  </div>    
              </div>
          </div>
      </div>
  </div> 


</body>
</html>
<script type="text/javascript">
    function myQue(id)
    {
        var cID = id;
        var queT = $("#txtQuestion").val();
        // alert(queT);
        $.ajax({
            type : "POST",
            data : { question : queT,cid : cID},
            url : "<?=site_url('User/MyCourseC/questionAsk/')?>",
            success : function(result){
                if(result=="1")
                {
                    $('.ask-question').css({"visibility":"hidden","display":"none"});
                    $("#txtQuestion").val("");
                    $.notify("Your question is submitted");
                }
                else
                {
                    $.notify("Your question is not submitted");
                }
            }
        });        
    }

    $("#asked").click(function() {
        if($('.ask-question').is(":visible"))
        {
            $('.ask-question').css({"visibility":"hidden","display":"none"});
        }
        else
        {
            $('.ask-question').css({"visibility":"visible","display":"block"});
        }
    });

</script>
<script type="text/javascript">
    $('#myTabs a').click(function (e) {
      e.preventDefault()
      $(this).tab('show')
  })
</script>
<script type="text/javascript">
    $(document).ready(function() {
        var id = "<?=$coursedata->courseID?>";
        var htmlText = '';
        $('[data-toggle="popover"]').popover({
            placement : 'bottom',
            trigger : 'hover',
            container : 'body',
            title : 'User Detail',
            html : true,
            content : function(){
                return $(this).next('.popper-content').html();
            }
        });
// Gets the video src from the data-src on each button
var $videoSrc;  
$('.video-btn').click(function() {
    $videoSrc = $(this).data( "src" );
});
console.log($videoSrc);
    // when the modal is opened autoplay it  
    $('#myModal').on('shown.bs.modal', function (e) {  
    // set the video src to autoplay and not to show related video. Youtube related video is like a box of chocolates... you never know what you're gonna get
    $("#video").attr('src',$videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0" ); 
})
    // stop playing the youtube video when I close the modal
    $('#myModal').on('hide.bs.modal', function (e) {
    // a poor man's stop video
    $("#video").attr('src',$videoSrc); 
})
    // document ready  
});
</script>
<!-- <script>
    $(document).ready(function(){
        $('[data-toggle="popover"]').popover();   
    });
</script> -->