    <!-- <script type="text/javascript" src="resources/js/jquery-3.4.1.js"></script> -->
    <script type="text/javascript" src="resources/js/jquery-1.12.4.min.js"></script>
    <script type="text/javascript" src="resources/js/bootstrap.js"></script>
    <script type="text/javascript" src="resources/js/owl.carousel.js"></script>
    <script type="text/javascript" src="resources/js/jquery.form-validator.min.js"></script>
    <script type='text/javascript' src='https://maps.google.com/maps/api/js?key=AIzaSyAciPo9R0k3pzmKu6DKhGk6kipPnsTk5NU'></script>
    <script type="text/javascript" src="resources/js/map-styleMain.js"></script>
    <script type="text/javascript" src="resources/js/placeholder.js"></script>
    <script type="text/javascript" src="resources/js/coustem.js"></script>
    <script src="assets/plugins/sweetalert/sweetalert.min.js"></script> <!-- sweetalert --> 
    <script type="text/javascript" src="resources/js/notify.js"></script>
    <script type="text/javascript" src="resources/js/bootstrap-notify.js"></script>
    <script src="assets/plugins/dropzone/dropzone.js"></script> <!-- Dropzone Plugin Js -->

