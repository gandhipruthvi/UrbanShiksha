<div class="quck-nav">
        	<div class="container">
            	<div class="contact-no"><a href="#"><i class="fa fa-map-marker"></i>Brooklyn, NY 10036, United States</a></div>
        		<div class="contact-no"><a href="#"><i class="fa fa-phone"></i>+299 97 39 82</a></div>
                <div class="contact-no"><a href="#"><i class="fa fa-globe"></i>academy.com</a></div>
                <div class="quck-right">
                	<div class="right-link"><a href="#"><i class="fa fa-handshake-o"></i>Help Center</a></div>
                    <div class="right-link"><a href="#"><i class="fa fa-headphones"></i>Online Support</a></div>
                    <?php
                        if(isset($this->session->userID))
                        {
                    ?>
                    <div class="right-link user-profileLink">
                        <a href="javascript:void(0);"><i class="fa  fa-user"></i><?=$this->session->userName?></a>
                        <ul class="accout-link">
                            <li><a href="<?=site_url('User/AccountSettingC/')?>">My Account</a></li>
                            <li><a href="<?=site_url('User/MyCourseC/')?>">My Courses</a></li>
                            <li><a href="<?=site_url('User/LogoutC/')?>"></i>Logout</a></li>
                        </ul>
                    </div>
                    <?php 
                        }
                        else
                        {
                    ?>
                    <div class="right-link"><a href="<?=site_url('User/LoginC/')?>"><i class="fa  fa-user"></i>Login \ Register</a></div>                    
                    <?php
                        }
                    ?>
                </div>
            </div>
        </div>