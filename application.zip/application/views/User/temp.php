<!DOCTYPE html>
<html>
<body>
	<pre>
		Please click the below link to verify your email
		<?php
			anchor("User/VerificationC/index/".$this->db->insert_id(),"Click here");
		?>
	</pre>
</body>
</html>