<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    <base href="<?=base_url();?>">

    <!-- Title -->
    <title>Academy</title>

    <!-- favicon icon -->
    <link rel="shortcut icon" href="resources/images/Favicon.ico">
    <!-- <link href="assets/css/main.css" rel="stylesheet"> -->
    <!-- CSS Stylesheet -->
    <!--Link Page-->
    <?php include_once("link.php");?>
    <!--#Link Page-->
</head>

<body>
    <div class="wapper">
        <!--quckNav-->
        <?php include_once("quckNav.php");?>
        <!--#quckNav-->
        <!--Header-->
        <?php include_once("header.php");?>
        <!--#Header-->
        <section class="banner inner-page">
            <div class="banner-img"><img src="resources/images/banner/cart.jpg" alt=""></div>
            <div class="page-title">	
                <div class="container">
                    <h1>Cart</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb ">
            <div class="container">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Cart</a></li>
                </ul>
            </div>
        </section>
        <section class="cart-page">
            <div class="container"><?php
            if($cartData!=null)
            {
                ?>
                <div class="table-view">
                    <div class="cart-table">
                        <table>
                            <tr>
                                <th>COURSE</th>
                                <th>PRICE</th>
                                <th>TOTAL</th>
                                <th>&nbsp;</th>
                            </tr>
                            <?php
                            foreach ($cartData as $key) {
                                ?>
                                <tr>
                                    <td>
                                        <div class="product-details">
                                            <div class="img"><img src="<?= base_url("upload/$key->image")?>" alt="" style="width:80px;height:65px;"></div>
                                            <div class="name"><?=$key->courseName?></div>
                                        </div>
                                    </td>
                                    <td><span class="small-text">PRICE</span><?=$key->price?></td>
                                    <td><span class="small-text">TOTAL</span><?=$key->price?></td>
                                    <td><span class="small-text">Remove Item</span><a href="<?=site_url('User/CartC/deleteCart/'.$key->courseID);?>" class="close-icon"><span>Delete</span><i class="fa fa-trash"></i></a></td>
                                </tr>
                                <?php
                            }
                            ?>
                        </table>
                    </div>
                    <div class="cart-total">
                        <table>
                            <?php
                                $total = 0;
                                foreach ($cartData as $key) 
                                {
                                    $total += $key->price;
                                }
                            ?>
                            <tr class="total">
                                <td>Total Amount:-</td>
                                <td>₹ <?=$total?></td>
                            </tr>
                            <?php
                            ?>
                        </table>
                    </div>
                </div>
                <div class="cart-row">
                    <div class="coupon-code">
                        <input type="text" placeholder="Coupon code">
                        <input type="submit" value="APPLY" class="btn">
                    </div>
                    <div class="check-outBtn">
                        <a href="<?=site_url('User/HomeC/paySuccess/'.$key->cartID.'/'.$total);?>" class="btn">Proceed to Checkout</a>
                    </div>
                </div>
                <?php
            }
            else
            {
                ?>
                <h2 style="text-align: center; font-size: 50px">Your shopping cart is empty</h2>
                <?php
            }
            ?>
        </div>
    </section>
    <section class="our-course">
        <div class="container">
            <div class="section-title">
                <h2>YOU MAY BE INTERESTED IN</h2>
            </div>
            <div class="row">
                <div class="col-md-4 col-sm-6">
                    <div class="course-box">
                        <div class="img">
                            <img src="resources/images/courses/courses-img1.jpg" alt="">
                            <div class="course-info">
                                <div class="date"><i class="fa fa-calendar"></i>16-09-2016</div>
                                <div class="date"><i class="fa fa-clock-o"></i>2 Days </div>
                                <div class="favorite"><a href="#"><i class="fa fa-heart-o"></i></a></div>
                            </div>
                            <div class="price">$100</div>
                        </div>
                        <div class="course-name">Management<span><em>By </em>Sarah Johnson</span></div>
                        <div class="comment-row">
                            <div class="rating">
                                <div class="fill" style="width:45%"></div>
                            </div>
                            <div class="box"><i class="fa fa-users"></i>35 Student</div>
                            <div class="enroll-btn">	
                                <a href="#" class="btn">Enroll</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="course-box">
                        <div class="img">
                            <img src="resources/images/courses/courses-img2.jpg" alt="">
                            <div class="course-info">
                                <div class="date"><i class="fa fa-calendar"></i>17-09-2016</div>
                                <div class="date"><i class="fa fa-clock-o"></i>1 Days </div>
                                <div class="favorite"><a href="#"><i class="fa fa-heart"></i></a></div>
                            </div>
                            <div class="price free">free</div>
                        </div>
                        <div class="course-name">Banking<span><em>By </em>Michael Windzor</span></div>
                        <div class="comment-row">
                            <div class="rating">
                                <div class="fill" style="width:45%"></div>
                            </div>
                            <div class="box"><i class="fa fa-users"></i>30 Student</div>
                            <div class="enroll-btn">	
                                <a href="#" class="btn">Enroll</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-sm-6">
                    <div class="course-box">
                        <div class="img">
                            <img src="resources/images/courses/courses-img3.jpg" alt="">
                            <div class="course-info">
                                <div class="date"><i class="fa fa-calendar"></i>17-09-2016</div>
                                <div class="date"><i class="fa fa-clock-o"></i>1 Days </div>
                                <div class="favorite"><a href="#"><i class="fa fa-heart-o"></i></a></div>
                            </div>
                            <div class="price">$276</div>
                        </div>
                        <div class="course-name">Government Recruitment<span><em>By </em>Peter Parker</span></div>
                        <div class="comment-row">
                            <div class="rating">
                                <div class="fill" style="width:45%"></div>
                            </div>
                            <div class="box"><i class="fa fa-users"></i>30 Student</div>
                            <div class="enroll-btn">	
                                <a href="#" class="btn">Enroll</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!--Footer Page-->
    <?php include_once("footer.php");?>
    <!--#Footer Page-->
</div>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <!--Script Page-->
    <?php include_once("script.php");?>
    <!--#Script Page-->
</body>
</html>

