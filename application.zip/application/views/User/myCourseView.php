<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    <base href="<?=base_url();?>">

    <!-- Title -->
    <title>Academy</title>

    <!-- favicon icon -->
    <link rel="shortcut icon" href="images/Favicon.ico">

    <!-- CSS Stylesheet -->
    <!--Link Page-->
    <?php include_once("link.php");?>
    <!--#Link Page-->

    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

<script type="text/javascript">
    cart0=<?= $cartdata?>;
    enroll0=<?= $enrollData?>;
</script>
</head>

<body>
    <div class="wapper">
        <!--quckNav-->
        <?php include_once("quckNav.php");?>
        <!--#quckNav-->

        <!--Header-->
        <?php include_once("header.php");?>
        <!--#Header-->
        <section class="banner inner-page">
            <div class="banner-img"><img src="images/banner/courses-banner.jpg" alt=""></div>
            <div class="page-title">    
                <div class="container">
                    <h1>courses details</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb">
            <div class="container">
                <ul>
                    <li><a href="<?= site_url('User/HomeC/')?>">Home</a></li>
                    <li><a href="<?= site_url('User/CourseC/')?>">All courses</a></li>
                    <li><a>courses details</a></li>
                </ul>
            </div>
        </section>
        <div class="course-details">
            <div class="container">
                <h2><?=$coursedata->courseName?></h2>
                <div class="course-details-main">
                    <div class="course-img">
                        <img src="<?= base_url("upload/$coursedata->image")?>" class="img-fluid" style="height:400px;width:1250px;">
                    </div>
                    <div class="course-info">
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file"></i></div>
                            <p>17 Lessons</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-exclamation"></i></div>
                            <p>7 Quizzes</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-file-text-o"></i></div>
                            <p>13 Documents</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-video-camera"></i></div>
                            <p>9 vedio</p>
                        </div>
                        <div class="course-box">
                            <div class="icon"><i class="fa fa-mortar-board"></i></div>
                            <p>1719 Students</p>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="course-instructorInfo">
                                <div class="info-slide"><i class="fa fa-user-secret"></i><?=$coursedata->userName;?></div>
                                <!--  <div class="info-slide"><i class="fa fa-calendar"></i>16-09-2016 - 15-08-2018 </div> -->
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="btn-row">
                                <div class="col-md-3"></div>
                                <?php
                                    if($coursedata->price==0)
                                    {
                                ?>
                                    <div class="price col-md-4" align="right"><span>Price: </span>Free</div>
                                <?php
                                    }
                                    else
                                    {
                                ?>
                                    <div class="price col-md-4" align="right"><span>Price: ₹ </span><?=$coursedata->price?></div>
                                <?php
                                    }
                                ?>
                                <?php
                                    if($coursedata->userID==$this->session->userID)
                                    {
                                ?>
                                    <div></div>
                                <?php
                                    }
                                    else
                                    {
                                        if($coursedata->price==0)
                                        {
                                ?>
                                    <div id="enroll">
                                            <a class="btn" id="btnenroll" data-id="<?= $coursedata->courseID?>" style="background-color: red;"><i class="fa fa-cart-plus"></i>Enroll</a>
                                    </div>
                                <?php
                                        }
                                        else
                                        {
                                ?>
                                    <div id="addToCart">
                                            <a class="btn" id="btnsubmit" data-id="<?= $coursedata->courseID?>"><i class="fa fa-cart-plus"></i>Add to Cart</a>
                                    </div>
                                <?php
                                        }
                                    }
                                ?>
                            </div>
                        </div>
                    </div>

                </div>
                <div class="info">
                    <h4>Course Overview</h4>
<!-- <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. </p>
    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you need to be sure there isn't anything embarrassing hidden in the middle of text. All the Lorem Ipsum generators on the Internet tend to repeat predefined chunks as necessary, making this the first true generator on the Internet. It uses a dictionary of over 200 Latin words, combined with a handful of model sentence structures, to generate Lorem Ipsum which looks reasonable. </p> -->
    <p><?=$coursedata->description?></p>
</div>
<div class="instructors">
    <h4>Meet The Instructors</h4>
    <div class="row">
        <div class="col-sm-4">
            <div class="instructors-box">
                <div class="img"><img src="images/user-img/img6.jpg" alt=""></div>
                <div class="name">variations passages</div>
                <div class="designation">reasonable</div>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                <div class="link"><a href="instructor-profile.html">More Info</a></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="instructors-box">
                <div class="img"><img src="images/user-img/img7.jpg" alt=""></div>
                <div class="name">variations passages</div>
                <div class="designation">reasonable</div>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                <div class="link"><a href="instructor-profile.html">More Info</a></div>
            </div>
        </div>
        <div class="col-sm-4">
            <div class="instructors-box">
                <div class="img"><img src="images/user-img/img8.jpg" alt=""></div>
                <div class="name">variations passages</div>
                <div class="designation">reasonable</div>
                <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or </p>
                <div class="link"><a href="instructor-profile.html">More Info</a></div>
            </div>
        </div>

    </div>
</div>
<div class="syllabus">
    <h4>Syllabus</h4>
    <div class="syllabus-box">
        <div class="syllabus-title">1st lesson</div>
        <div class="syllabus-view first">
            <div class="main-point active">Lorem Ipsum is simply dummy text of the printing and typesetting</div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">vedio : Lorem ipsum dolor sit amet. <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="course-lessons.html">Document : semper dolor quis lectus facilisis laoreet. <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="quiz-intro.html">Quizzes : auctor quam quis commodo feugiat. <span class="hover-text">upgrade now<i class="fa fa-angle-right"></i></span></a></li>
                    <li class="no-link">There are many variations of passages of Lorem Ipsum available, </li>
                </ul>
            </div>
        </div>
    </div>
    <div class="syllabus-box">
        <div class="syllabus-title">2st lesson</div>
        <div class="syllabus-view">
            <div class="main-point">It is a long established fact that a reader will be distracted by the</div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">Lessons : auctor quam quis commodo feugiat. <span class="hover-text">understand now<i class="fa fa-angle-right"></i></span></a></li>                                  
                    <li><a href="course-lessons.html">vedio : Lorem ipsum dolor sit amet. <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="course-lessons.html">Document : semper dolor quis lectus facilisis laoreet. <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="quiz-intro.html">Quizzes : auctor quam quis commodo feugiat. <span class="hover-text">upgrade now<i class="fa fa-angle-right"></i></span></a></li>

                </ul>
            </div>
        </div>
    </div>
    <div class="syllabus-box">
        <div class="syllabus-title">3st lesson</div>
        <div class="syllabus-view">
            <div class="main-point">readable content of a page when looking at its layout. The point of </div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">Lessons : auctor quam quis commodo feugiat. <span class="hover-text">understand now<i class="fa fa-angle-right"></i></span></a></li>                                  
                    <li><a href="course-lessons.html">vedio : Lorem ipsum dolor sit amet. <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="course-lessons.html">Document : semper dolor quis lectus facilisis laoreet. <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i></span></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="syllabus-box">
        <div class="syllabus-title">4st lesson</div>
        <div class="syllabus-view">
            <div class="main-point">using Lorem Ipsum is that it has a more-or-less normal distribution </div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">Lessons : auctor quam quis commodo feugiat. <span class="hover-text">understand now<i class="fa fa-angle-right"></i></span></a></li>                                  
                    <li><a href="course-lessons.html">vedio : Lorem ipsum dolor sit amet. <span class="hover-text">Watch Video<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="quiz-intro.html">Quizzes : auctor quam quis commodo feugiat. <span class="hover-text">upgrade now<i class="fa fa-angle-right"></i></span></a></li>
                </ul>
            </div>
        </div>
    </div>
    <div class="syllabus-box">
        <div class="syllabus-title">5st lesson</div>
        <div class="syllabus-view">
            <div class="main-point">of letters, as opposed to using 'Content here, content here', </div>
            <div class="point-list">
                <ul>
                    <li><a href="course-lessons.html">Lessons : auctor quam quis commodo feugiat. <span class="hover-text">understand now<i class="fa fa-angle-right"></i></span></a></li>                                  
                    <li><a href="course-lessons.html">Document : semper dolor quis lectus facilisis laoreet. <span class="hover-text">Let's Go<i class="fa fa-angle-right"></i></span></a></li>
                    <li><a href="quiz-intro.html">Quizzes : auctor quam quis commodo feugiat. <span class="hover-text">upgrade now<i class="fa fa-angle-right"></i></span></a></li>
                </ul>
            </div>
        </div>
    </div>

</div>
<div class="reviews">
<!-- <h4>Reviews</h4>
<div class="row">
<div class="col-sm-5">
<div class="rating-info">
<label>Detailed Rating</label>
<div class="rating-slide">
<span>Stars 5</span>
<div class="bar">
<div class="fill" style="width:50%"></div>
</div>
<em>10</em>
</div>
<div class="rating-slide">
<span>Stars 4</span>
<div class="bar">
<div class="fill" style="width:40%"></div>
</div>
<em>8</em>
</div>
<div class="rating-slide">
<span>Stars 3</span>
<div class="bar">
<div class="fill" style="width:30%"></div>
</div>
<em>6</em>
</div>
<div class="rating-slide">
<span>Stars 2</span>
<div class="bar">
<div class="fill" style="width:35%"></div>
</div>
<em>7</em>
</div>
<div class="rating-slide">
<span>Stars 1</span>
<div class="bar">
<div class="fill" style="width:0"></div>
</div>
<em>0</em>
</div>
</div>
</div>
<div class="col-sm-5">
<label>Average Rating</label>
<div class="rating-box">
<div class="rating">4.3</div>
<div class="rating-star">
<div class="fill" style="width:86%"></div>
</div>
<span>31 Ratings</span>
</div>
</div>
</div> -->
<div class="reviews-view">
    <h4>Reviews List</h4>
    <div class="reviews-slide">
        <?php
        foreach ($reviewdata as $key) { 
            ?>
            <div class="row">
                <div class="col-md-2">
                    <div class="img-responsive img-circle" style="text-align:center"><img src="<?= base_url("upload/$key->image")?>" style="width:80px;height:80px;border-radius:50%"></div>
                </div>
                <div class="col-md-10">
                    <span style="color:RED"><?=$key->userName?></span><br>
                    <?php 
                    for($i=1;$i<=5;$i++)
                    {
                        if($key->stars>=$i)
                        {
                            ?>
                            <i class="fill fa fa-star" style="color:orange;"></i>
                            <?php
                        }
                        else
                        {
                            ?>
                            <i class="fa fa-star-o" style="color:orange;"></i>
                            <?php
                        }
                    }
                    ?>



                    <p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words which don't look even slightly believable. If you are going to use a passage of Lorem Ipsum, you </p>
                </div>
            </div>
            <?php
        }
        ?>

    </div>

</div>
</div>
</div>
</div>
<!--Footer Page-->
<?php include_once("footer.php");?>
<!--#Footer Page-->
</div>
<!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <!--Script Page-->
    <?php include_once("script.php");?>
    <!--#Script Page-->
        <script type="text/javascript">
            $("#btnenroll").click(function() {
                var eid=$(this).data("id");
                // alert(eid);
                if(enroll0==0)
                {
                    $.ajax({
                        url : "<?= site_url("User/CourseEnrollC/index/")?>"+eid, 
                        success: function(result){
                            $.notify({
                                message:"Course Enrolled"
                            },{
                                type:'success',
                                allow_dismiss: false,
                                placement: {
                                    from: "bottom",
                                    align: "right"
                                },
                                delay: 1000,
                                animate: {
                                    enter: 'animated fadeInDown',
                                    exit: 'animated fadeOutUp'
                                },
                                onShow: function(){
                                    this.css({'width':'auto','height':'auto'});
                                },
                            });
                            enroll0=1;
                        }                        
                    });
                }
                else
                {
                    $.notify({
                        message:"Already Enrolled"
                    },{
                        type:'danger',
                        allow_dismiss: false,
                        placement: {
                            from: "bottom",
                            align: "right"
                        },
                        delay: 1000,
                        animate: {
                            enter: 'animated fadeInDown',
                            exit: 'animated fadeOutUp'
                        },
                        onShow: function() {
                            this.css({'width':'auto','height':'auto'});
                        },
                    });
                }                
            });
        </script>
        <script type="text/javascript">
            $("#btnsubmit").click(function(){
                var cid=$(this).data("id");
                if(cart0==0)
                {
                    $.ajax({
                        url : "<?= site_url("User/CartC/index/")?>"+cid, 
                        success: function(result){
                            $.notify({
                                message:"Course added in your cart"
                            },{
                                type:'success',
                                allow_dismiss: false,
                                placement: {
                                    from: "bottom",
                                    align: "right"
                                },
                                delay: 1000,
                                animate: {
                                    enter: 'animated fadeInDown',
                                    exit: 'animated fadeOutUp'
                                },
                                onShow: function(){
                                    this.css({'width':'auto','height':'auto'});
                                },
                            });
                            cart0=1;
                        }
                    });
                }
                else
                {
                    $.notify({
                        message:"Already in your cart"
                    },{
                        type:'danger',
                        allow_dismiss: false,
                        placement: {
                            from: "bottom",
                            align: "right"
                        },
                        delay: 1000,
                        animate: {
                            enter: 'animated fadeInDown',
                            exit: 'animated fadeOutUp'
                        },
                        onShow: function() {
                            this.css({'width':'auto','height':'auto'});
                        },
                    });
                }
            });
        </script>
    </body>
    </html>

