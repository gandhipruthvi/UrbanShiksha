<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Meta information -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
  <base href="<?=base_url();?>">


<style>
    .panel-heading:after {
    content: "\2212";
    color: #000000;
    font-weight: bold;
    float: right;
    margin-top: -15px;
    }

    .panel-heading.collapsed:after {
      content: "\002B";
      color: #000000;        
    }
    .ml-menu  {
     list-style-type: none;
   }
</style> 
<!-- Title -->
<title>Academy</title>

<!-- favicon icon -->
<link rel="shortcut icon" href="resources/images/Favicon.ico">
<!-- <link href="assets/css/main.css" rel="stylesheet"> -->
<!-- CSS Stylesheet -->
<!--Link Page-->
<?php include_once("link.php");?>
<!--#Link Page-->

<!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
<!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js"></script>
<![endif]-->

</head>

<body>
  <div class="wapper">
    <!--quckNav-->
    <?php include_once("quckNav.php");?>
    <!--#quckNav-->

    <!--Header-->
    <?php include_once("header.php");?>
    <!--#Header-->
    <section class="banner inner-page">
      <div class="banner-img"><img src="resources/images/banner/courses-banner.jpg" alt=""></div>
      <div class="page-title">	
        <div class="container">
          <h1>Courses List Sidebar</h1>
        </div>
      </div>
    </section>
    <section class="breadcrumb">
      <div class="container">
        <ul>
          <li><a href="<?= site_url('User/HomeC/')?>">Home</a></li>
          <li><a href="<?= site_url('User/CourseC/')?>">All courses</a></li>
        </ul>
      </div>
    </section>
    <section class="courses-view list-view">
      <div class="container">
        <div class="row">
          <div class="col-md-3">
            <div class="right-slide left">
              <div class="panel-group" id="accordion">
                <?php 
                foreach ($categorydata as $key)
                {
                  ?>
                  <div class="panel panel-default" style="background-color: white;border-color: white;">
                    <div class="panel-heading collapsed"  data-toggle="collapse"  href="#collapse<?= $key->categoryID?>" style="background-color: white;border-color: white;">
                      <h4 class="panel-title">
                        <div><?=$key->categoryName?></div>
                      </h4>
                    </div>
                    <div id="collapse<?= $key->categoryID?>" class="panel-collapse collapse" data-parent="#accordion">
                      <div class="panel-body">
                        <?php 
                        foreach ($key->subCategory as $key1) 
                        {
                          ?>
                          <ul class="ml-menu">
                            <li>
                              <!-- <a href="<?=site_url('User/CourseC/index/'.$key1->subcategoryID);?>"  style="color:black;"><?= $key1->subcategoryName;?></a> -->
                              <a style="color:black;"><?= $key1->subcategoryName;?></a>
                            </li>
                          </ul>
                          <?php
                        }
                        ?>
                      </div>
                    </div>
                  </div>
                  <?php
                }
                ?>
              </div> 
              <h3>Price</h3>
              <form method="post" action="<?=site_url('User/SortC/')?>" enctype="multipart/form-data">
                <div class="filter-blcok">
                  <div class="check-slide">
                    <label class="label_check" for="checkbox-01"><input name="sort[]" id="checkbox-01" type="checkbox" value="Free" <?php if(isset($price))
                    {
                      if($price==0 || $price==2)
                        {echo "checked";}  
                    }
                    ?>> Free</label>
                  </div>
                  <div class="check-slide">
                    <label class="label_check" for="checkbox-02"><input name="sort[]" id="checkbox-02" type="checkbox" value="Paid" <?php if(isset($price))
                    {
                      if($price==1 || $price==2)
                        {echo "checked";}  
                    }
                    ?>> Paid</label>
                  </div>
                </div>
              </form>
              <h3>Language</h3>
              <div class="filter-blcok">
                <div class="check-slide">
                  <label class="label_check" for="checkbox-03"><input id="checkbox-03" type="checkbox"> Chinese</label>
                </div>
                <div class="check-slide">
                  <label class="label_check" for="checkbox-04"><input id="checkbox-04" type="checkbox"> English</label>
                </div>
                <div class="check-slide">
                  <label class="label_check" for="checkbox-05"><input id="checkbox-05" type="checkbox"> French</label>
                </div>
                <div class="check-slide">
                  <label class="label_check" for="checkbox-06"><input id="checkbox-06" type="checkbox"> Portuguese</label>
                </div>
              </div>
              <h3>Related Courses</h3>
              <div class="recent-post">
                <div class="post-slide">
                  <div class="img"><img src="resources/images/blog/post-img1.jpg" alt=""></div>
                  <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                  <div class="date">$200</div>
                </div>
                <div class="post-slide">
                  <div class="img"><img src="resources/images/blog/post-img2.jpg" alt=""></div>
                  <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                  <div class="date">FREE</div>
                </div>
                <div class="post-slide">
                  <div class="img"><img src="resources/images/blog/post-img3.jpg" alt=""></div>
                  <p><a href="#">when an unknown printer took a galley of type and scrambled</a></p>
                  <div class="date">$78</div>
                </div>
              </div>

              <h3>Keywords</h3>
              <ul class="keyword-list">
                <li><a href="#">Html</a></li>
                <li><a href="#">Boostrap</a></li>
                <li><a href="#">Css3</a></li>
                <li><a href="#">Jquery</a></li>
                <li><a href="#">Student</a></li>
                <li><a href="#">Html</a></li>
                <li><a href="#">Boostrap</a></li>
                <li><a href="#">Css3</a></li>
                <li><a href="#">Jquery</a></li>
                <li><a href="#">Student</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-9">
            <div class="filter-row">
              <div class="view-type">
                <a href="courses-gride-sideBar.html"><i class="fa fa-th-large"></i></a>
                <a href="courses-list-sideBar.html"><i class="fa fa-list"></i></a>
              </div>

              <div class="search">
                <!-- <form method="post" action="<?=site_url('User/CourseC/searchCourse');?>"> -->
                  <input type="text" placeholder="Search" name="txtSearch" id="txtSearch">
                  <input type="submit" value="">
                  <!-- </form> -->
                </div>
              </div>
              <div class="course-post">

              </div>
              <div class="pagination">
                <ul class="tsc_pagination">
                  <li id="pagination"></li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>
  <!--Footer Page-->
  <?php include_once("footer.php");?>
  <!--#Footer Page-->
</div>
<!-- Bootstrap core JavaScript
  ================================================== -->
  <!-- Placed at the end of the document so the pages load faster -->

  <!--Script Page-->
  <?php include_once("script.php");?>
  <!--#Script Page-->
</body>
</html>
<script>
  var coll = document.getElementsByClassName("collapsible");
  var i;

  for (i = 0; i < coll.length; i++) {
    coll[i].addEventListener("click", function() {
      this.classList.toggle("active");
      var content = this.nextElementSibling;
      if (content.style.maxHeight){
        content.style.maxHeight = null;
      } else {
        content.style.maxHeight = content.scrollHeight + "px";
      } 
    });
  }
</script>
<script type="text/javascript">
 loadPagination(0);

 $('#pagination').on('click','a',function(e){
   e.preventDefault(); 
   var pageno = $(this).attr('data-ci-pagination-page');
   loadPagination(pageno);
 });

 $("#txtSearch").keyup(function(){
  loadPagination(0);
});

 $("#checkbox-01").click(function(){
  loadPagination(0);
 });

 $("#checkbox-02").click(function(){
  loadPagination(0);
 });

 function loadPagination(pagno){
  var bs = "<?=base_url("upload/")?>";
  var txtSearch= $("#txtSearch").val();
  var checkPaid = null;
  var checkFree = null;
  if($('#checkbox-01').is(':checked')){
    var checkFree = $("#checkbox-01").val();
  }
  if($('#checkbox-02').is(':checked')){
    var checkPaid = $("#checkbox-02").val();
  }
  var htmlText = '';
  $.ajax({
    type: "POST",
    data : {searcht : txtSearch,checkF : checkFree,checkP : checkPaid},
    url: '<?= site_url('User/MyCourseC/paginate/')?>'+pagno,
    success: function(result){
      var res = JSON.parse(result);
      $('#pagination').html(res.pagination);
      var key = res.courseData;
      $('.course-post').empty();
      for (var data in key)
      {
        htmlText += '<div class="img"><img src="'+bs+key[data].image+'" ';
        htmlText += 'style="height:182px;width:218px;">';
        htmlText += '<div class="icon">';
        htmlText += '<a href="#"><img src="resources/images/book-icon.png" alt=""></a>';
        htmlText += '</div>';
        if(key[data].price==0)
        {
          htmlText += '<div class="price free" style="width:80px;">Free</div>';
        }
        else
        {
          htmlText += '<div class="price" style="width:80px;">₹ '+key[data].price+'</div>';
        }
        htmlText += '</div>';
        htmlText += '<div class="info">';
        htmlText += '<div class="name" id="courseName">'+key[data].courseName+'</div>';
        htmlText += '<div class="expert" id="userName"><span>By </span>'+key[data].userName+'</div>';
        htmlText += '<div class="product-footer">';
        htmlText += '<div class="comment-box">';
        htmlText += '<div class="box" id="count"><i class="fa fa-users"></i>Enrolled:-'+key[data].enID.count+'</div>';
        htmlText += '</div>';
        htmlText += '<div class="rating">';
        htmlText += '<div class="fill" style="width:45%"></div>';
        htmlText += '</div>';
        htmlText += '<p id="description">'+key[data].description+'</p>';
        htmlText += '<div class="view-btn2">';
        htmlText += '<a href="<?=site_url("User/MyCourseC/viewCourse/")?>'+key[data].courseID+'" class="btn2">view more</a>';
        htmlText += '</div>';
        htmlText += '</div>';
        htmlText += '</div>';
        htmlText += '<pre style="background-color: white; border: 0"></pre>';
      }
      $(".course-post").append(htmlText);
    }
  });
}
</script>