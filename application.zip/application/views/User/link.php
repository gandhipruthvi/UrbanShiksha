<!-- favicon icon -->
    <link rel="shortcut icon" href="images/Favicon.ico">
    
    <!-- CSS Stylesheet -->
    <link href="resources/css/bootstrap.css" rel="stylesheet"><!-- bootstrap css -->
    <link href="resources/css/owl.carousel.css" rel="stylesheet"><!-- carousel Slider -->
    <link href="resources/css/font-awesome.css" rel="stylesheet"><!-- font awesome -->
    <link href="resources/css/loader.css" rel="stylesheet"><!--  loader css -->
    <link href="resources/css/docs.css" rel="stylesheet"><!--  template structure css -->
    <link href="https://fonts.googleapis.com/css?family=Arima+Madurai:100,200,300,400,500,700,800,900%7CPT+Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
    <link href="resources/css/animate.css" rel="stylesheet"><!--  template structure css -->
    

