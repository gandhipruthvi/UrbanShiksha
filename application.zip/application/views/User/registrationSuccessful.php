<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Meta information -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0"><!-- Mobile Specific Metas -->
    <base href="<?=base_url();?>">

    <!-- Title -->
    <title>Academy</title>

    <!-- favicon icon -->
    <link rel="shortcut icon" href="resources/images/Favicon.ico">
    <!-- <link href="assets/css/main.css" rel="stylesheet"> -->
    <!-- CSS Stylesheet -->
    <!--Link Page-->
    <?php include_once("link.php");?>
    <!--#Link Page-->
</head>
    
<body>
    <div class="wapper">
        <div class="quck-nav">
        	<div class="container">
            	<div class="contact-no"><a href="#"><i class="fa fa-map-marker"></i>Brooklyn, NY 10036, United States</a></div>
        		<div class="contact-no"><a href="#"><i class="fa fa-phone"></i>+299 97 39 82</a></div>
                <div class="contact-no"><a href="#"><i class="fa fa-globe"></i>academy.com</a></div>
                <div class="quck-right">
                	<div class="right-link"><a href="#"><i class="fa fa-handshake-o"></i>Help Center</a></div>
                    <div class="right-link"><a href="#"><i class="fa fa-headphones"></i>Online Support</a></div>
                    <div class="right-link language-select">
                    	<a href="javascript:void(0);"><i class="fa fa-language"></i>English</a>
                        <ul class="language-list">
                        	<li><a href="#">Guyana</a></li>
                            <li><a href="#">Haiti</a></li>
                            <li><a href="#">Honduras</a></li>
                            <li><a href="#">Andorra</a></li>
                            <li><a href="#">Armenia</a></li>
                            <li><a href="#">Bahrain</a></li>
                        </ul>
                    </div>
                    <div class="right-link"><a href="login-register.html"><i class="fa  fa-user"></i>Login \ Register</a></div>
                </div>
            </div>
        </div>
        <header id="header">
        	<div class="container">
                <nav id="nav-main">
                    <div class="navbar navbar-inverse">
                        <div class="navbar-header">
                            <a href="index.html" class="navbar-brand"><img src="images/logo.png" alt=""></a>
                            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                                <span class="icon-bar"></span>
                            </button>
                        </div>
                        <div class="cart-box">
                        	<a href="cart.html"><i class="fa fa-shopping-basket"></i></a>
                        </div>
                        <div class="navbar-collapse collapse">
                            <ul class="nav navbar-nav">
                                <li class="sub-menu">
                                	<a href="index.html">Home </a>
                                    <ul>
                                    	<li><a href="index.html">Home-1</a></li>
                                        <li><a href="index-2.html">Home-2</a></li>
                                    </ul>
                                </li>
                                <li class="mega-menu sub-menu">
                                	<a href="courses-list.html">Courses</a>
                                    <div class="menu-view">
                                    	<div class="row">
                                        	<div class="col-sm-4">
                                            	<div class="menu-title">Courses Page</div>
                                            	<ul>
                                                	<li><a href="courses-gride.html">Courses Grid</a></li>
                                                    <li><a href="courses-gride-sideBar.html">Courses Grid SideBar</a></li>
                                                    <li><a href="courses-list.html">Courses List</a></li>
                                                    <li><a href="courses-list-sideBar.html">Courses List SideBar</a></li>
                                                    <li><a href="course-details.html">Course Details</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                            	<div class="menu-title">Quiz Page</div>
                                            	<ul>
                                                	<li><a href="quiz-intro.html">Quiz Intro</a></li>
                                                    <li><a href="quiz.html">Quiz</a></li>
                                                    <li><a href="quiz-result.html">Quiz Result</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4 menu-courses">
                                            	<div class="menu-title">Popular Courses</div>
                                                <div class="courses-slide">
                                                	<div class="img"><img src="images/blog/post-img1.jpg" alt=""></div>
                                                    <div class="name"><a href="courses-gride.html">Business Management</a></div>
                                                    <div class="price">$500</div>
                                                </div>
                                                <div class="courses-slide">
                                                	<div class="img"><img src="images/blog/post-img2.jpg" alt=""></div>
                                                    <div class="name"><a href="courses-gride.html">Computing Science</a></div>
                                                    <div class="price">$255</div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="active sub-menu mega-menu"> 
                                	<a href="#">Pages </a>
                                    <div class="menu-view">
                                    	<div class="row">
                                        	<div class="col-sm-4">
                                            	<div class="menu-title">Pages</div>
                                            	<ul>
                                        			<li><a href="blog.html">Blog</a></li>
                                                    <li><a href="blog-details.html">Blog Details</a></li>
                                                    <li><a href="cart.html">Cart</a></li>
                                                    <li><a href="check-out.html">Check Out</a></li>
                                                    <li><a href="instructors.html">Instructors</a></li>
                                        			<li><a href="instructor-profile.html">Instructor Profile</a></li>
                                                    <li><a href="faq.html">Faq</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                            	<div class="menu-title"></div>
                                            	<ul>
                                                	<li><a href="course-details-free.html">Course Details Free</a></li>
                                        			<li><a href="course-lessons.html">Course Lessons</a></li>
                                                    <li><a href="gallery.html">Gallery</a></li>
                                                    <li><a href="thank-you.html">Thank You</a></li>
                                                    <li><a href="coming-soon.html">Comming Soon</a>
                                                    <li><a href="page-404.html">404 Page</a></li>
                                                    <li><a href="certificate.html">Certificate</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                            	<div class="menu-title">After Login</div>
                                            	<ul>
                                                	
                                                    <li><a href="login-register.html">Login Register</a></li>
                                                    <li><a href="account-settings.html">Account Settings</a></li>
                                                    <li><a href="my-courses.html">My Courses</a></li>
                                                    <li><a href="course-progress.html">Course Progress</a></li>
                                                    <li><a href="course-home.html">Course Home</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li class="sub-menu">
                                	<a href="#">Features</a>
                                    <ul>
                                    	<li><a href="typography.html">Typography</a></li>
                                        <li><a href="price-plan.html">Price Plan</a></li>
                                        <li><a href="testimonial.html">Testimonial</a></li>
                                    </ul>
                                </li>
                                <li><a href="about-us.html">About Us</a></li>
                                <li class="sub-menu">
                                	<a href="event.html">Event</a>
                                    <ul>
                                    	<li><a href="event.html">Event</a></li>
                                        <li><a href="event-details.html">Event Details</a></li>
                                        <li><a href="event-details2.html">Event Details2</a></li>
                                    </ul>
                                </li>
                                <li class="sub-menu mega-menu">
                                	<a href="forums.html">Forums</a>
                                    <div class="menu-view">
                                    	<div class="row">
                                        	<div class="col-sm-4">
                                            	<div class="menu-title">Forums</div>
                                                <ul>
                                                	<li><a href="forums-detail.html">Forums Detail</a></li>
                                                    <li><a href="forums-group.html">Forums Group</a></li>
                                                    <li><a href="forums-group-details.html">Forums Group Details</a></li>
                                                    <li><a href="forums-group-member.html">Forums Group Member</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                            	<div class="menu-title"></div>
                                                <ul>
                                                	<li><a href="forum-single-topic.html">Forum Single Topic</a></li>
                                                    <li><a href="forums-members.html">Forums Members</a></li>
                                                    <li><a href="forums-profile.html">Forums Profile</a></li>
                                                    <li><a href="forums-profile-activity.html">Forums Profile Activity</a></li>
                                                </ul>
                                            </div>
                                            <div class="col-sm-4">
                                            	<div class="menu-title"></div>
                                                <ul>
                                                	<li><a href="forums-profile-forums.html">Forums Profile Forums</a></li>
                                                    <li><a href="forums-profile-friends.html">Forums Profile Friends</a></li>
                                                    <li><a href="forums-profile-groups.html">Forums Profile Groups</a></li>
                                                    <li><a href="forums-single-profile.html">Forums Single Profile</a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <li><a href="contact-us.html">Contact Us </a></li>
                            </ul>
                        </div>
                    </div>
                </nav>
            </div>
        </header>
        <section class="banner inner-page">
        	<div class="banner-img"><img src="images/banner/thank-you.jpg" alt=""></div>
            <div class="page-title">	
	            <div class="container">
                    <h1>Verification</h1>
                </div>
            </div>
        </section>
        <section class="breadcrumb ">
        	<div class="container">
            	<ul>
                	<li><a href="#">Home</a></li>
                    <li><a href="#">Thank you</a></li>
                </ul>
            </div>
        </section>
        <section class="thankYou-page">
        	<div class="container">
                <div class="section-title">
                    <h2 style="text-align: center; font-size: 50px">Verification mail successfuly sent</h2>
                    <a href="<?=site_url('User/LoginC/')?>" style="text-align: center; font-size: 25px">Login</a>
                </div>
            </div>
        </section>
        <footer id="footer">
        	<div class="footer-top">
            	<div class="container">
                	<div class="row">
                    	<div class="col-sm-6 col-md-3">
                        	<h5>Popular Courses</h5>
                            <div class="course-slide">
                            	<div class="img"><img src="images/blog/post-img1.jpg" alt=""></div>
                                <p><a href="courses-list.html">when an unknown printer took </a></p>
                                <div class="price">$55</div>
                            </div>
                            <div class="course-slide">
                            	<div class="img"><img src="images/blog/post-img2.jpg" alt=""></div>
                                <p><a href="courses-list-sideBar.html">when an unknown printer took </a></p>
                                <div class="price">$505</div>
                            </div>
                            <div class="course-slide">
                            	<div class="img"><img src="images/blog/post-img3.jpg" alt=""></div>
                                <p><a href="courses-list.html">when an unknown printer took </a></p>
                                <div class="price">$178</div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                        	<div class="row">
                            	<div class="col-md-offset-1 col-sm-6 col-md-5 col-xs-6">
                                	<h5>Company</h5>
                                    <ul class="footer-link">
                                        <li><a href="about-us.html">About Us</a></li>
                                        <li><a href="contact-us.html">Contact</a></li>
                                        <li><a href="blog.html">Blog</a></li>
                                        <li><a href="event.html">Event</a></li>
                                        <li><a href="gallery.html">Gallery</a></li>
                                        <li><a href="instructor-profile.html">Instructor Profile</a></li>
                                    </ul>	
                                </div>
                                <div class="col-md-offset-1 col-sm-6 col-md-5 col-xs-6">
                                	<h5>Links</h5>
                                    <ul class="footer-link">
                                    	<li><a href="courses-list.html">Courses List</a></li>
                                        <li><a href="price-plan.html">Pricing Table</a></li>
                                        <li><a href="instructors.html">Instructors</a></li>
                                        <li><a href="forums.html">Forums</a></li>
                                        <li><a href="faq.html">Faq</a></li>
                                    </ul>	
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6 col-md-3">
                        	<h5>Contact Us</h5>
                            <div class="contact-view">
                            	<div class="contact-slide">
                                	<p><i class="fa fa-location-arrow"></i>76 Woodland Ave. Sherman Drive  <br>Fort Walton Beach,Harlingen</p>
                                </div>
                                <div class="contact-slide">
                                	<p><i class="fa fa-phone"></i>+299 97 39 82</p>
                                </div>
                                <div class="contact-slide">
                                	<p><i class="fa fa-fax"></i>(08) 8971 7450</p>
                                </div>
                                <div class="contact-slide">
                                	<p><i class="fa fa-envelope"></i><a href="mailTo:academy@info.com">academy@info.com</a></p>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        	<div class="container">
            	<div class="row">
                	<div class="col-sm-8">
            			<div class="copy-right">
                        	<p>Copyright © <span class="year">2016</span> Academy.</p>
                            <ul class="footer-link">
                            	<li><a href="#">Terms and Conditions</a></li>
                                <li><a href="#">Privacy</a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-sm-4 ">	
                    	<div class="social-media">
                        	<ul>
                            	<li><a href="#"><i class="fa fa-facebook"></i></a></li>
                                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                                <li><a href="#"><i class="fa fa-skype"></i></a></li>
                                <li><a href="#"><i class="fa fa-youtube"></i></a></li>
                                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    </div>
    </div>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->

    <!--Script Page-->
    <?php include_once("script.php");?>
    <!--#Script Page-->
</body>
</html>

