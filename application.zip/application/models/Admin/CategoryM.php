<?php

defined('BASEPATH') OR exit('Ille');

class CategoryM extends CI_Model
{
	public function fetchAllCategory()
	{
		// $this->db->select("c.categoryName,sc.subcategoryName");
		// $this->db->from("tblCategory as c");
		// $this->db->join("tblSubCategory as sc","sc.categoryID=c.categoryID");
		// return $this->db->get()->result();
		return $this->db->get("tblCategory")->result();

	}

	public function fetchAllSubCategory()
	{
		return $this->db->get("tblSubCategory")->result();

	}
	public function fetchAllSubject()
	{
		return $this->db->get("tblSubject")->result();

	}

	public function addCategory($data)
	{
		$this->db->insert("tblCategory",$data);
	}
	
	public function addSubcategory($data)
	{
		$this->db->insert("tblSubcategory",$data);
	}
}	
?>