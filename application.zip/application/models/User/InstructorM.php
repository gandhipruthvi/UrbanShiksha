<?php
defined('BASEPATH') OR exit('Ille');

class InstructorM extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}
}
?>