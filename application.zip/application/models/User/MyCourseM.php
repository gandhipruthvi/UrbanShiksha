<?php

defined('BASEPATH') OR exit('Ille');
/**
 * 
 */
class MyCourseM extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	// public function fetchEnrollCourse($limit,$start)
	// {
	// 	$this->db->limit($limit,$start);
	// 	$this->db->select("c.*,e.*,u.userName");
	// 	$this->db->from("tblCourseEnrollment e");
	// 	$this->db->join("tblCourse c","c.courseID = e.courseID");
	// 	$this->db->join("tblUser u","u.userID = e.UserID");
	// 	$this->db->where("e.userID",$this->session->userID);
	// 	return $this->db->get()->result();
	// }

	public function fetchEnrollCourse($limit,$page,$searcht=null,$price=null)
	{
		$this->db->select("c.*,e.*,u.userName");
		$this->db->from("tblCourseEnrollment e");
		$this->db->join("tblCourse c","c.courseID = e.courseID");
		$this->db->join("tblUser u","u.userID = c.UserID");
		if($price!="" || $price!=null || $searcht!="")
		{
			if($price=='0')
				$this->db->where("c.price",$price);
			elseif($price=='1')
				$this->db->where("c.price >=",$price);
			if($searcht!="")
			{
				$this->db->like("courseName",$searcht);
			}
		}
		$this->db->limit($page,$limit);
		$this->db->where("e.userID",$this->session->userID);
		return $this->db->get()->result();
	}

	public function getCount($searcht=null,$price=null)
	{
		if($price!="" || $price!=null || $searcht!="")
		{
			if($price=='0')
				$this->db->where("c.price",$price);
			elseif($price=='1')
				$this->db->where("c.price >=",$price);
			if($searcht!="")
			{
				$this->db->like("c.courseName",$searcht);
			}
			$this->db->from("tblCourseEnrollment e");
			$this->db->join("tblCourse c","c.courseID = e.courseID");
			$this->db->where("e.userID",$this->session->userID);
			return $this->db->get()->num_rows();
		}
		else
		{
			$this->db->from("tblCourseEnrollment e");
			$this->db->join("tblCourse c","c.courseID = e.courseID");
			$this->db->where("e.userID",$this->session->userID);
			return $this->db->get()->num_rows();
		}
	}

	public function setQuestion($data)
	{
		return $this->db->insert("tblQuestion",$data);
	}

	public function fetchQuestion($id)
	{
		$this->db->select("q.questionID,q.question,u.userName,u.image,q.date");
		$this->db->from("tblQuestion q");
		$this->db->join("tblUser u","u.userID = q.userID");
		$this->db->where("q.courseID",$id);
		return $this->db->get()->result();	
	}

	public function fetchAnswer($qID)
	{
		$this->db->select("a.answerID,a.answer,q.question,u.userName,u.image,u.qualification,u.email,a.date");
		$this->db->from("tblAnswer a");
		$this->db->join("tblQuestion q","q.questionID = a.questionID");
		$this->db->join("tblUser u","u.userID = a.userID");
		$this->db->where('a.questionID',$qID);
		return $this->db->get()->result();
	}
}
?>