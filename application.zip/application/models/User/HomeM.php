<?php

defined('BASEPATH') OR exit('Ille');
/**
 * 
 */
class HomeM extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function insertOrder($data)
	{
		 $this->db->insert("tblOrder",$data);
		 return $this->db->insert_id();
	}

	public function insertPayment($data)
	{
		 $this->db->insert("tblPayment",$data);
	}

	public function insertOrderCourse($data)
	{
			$this->db->insert("tblordercourse",$data);	
	}

	public function insertCourseEnrollment($data)
	{
			$this->db->insert("tblcourseenrollment",$data);	
	}
	
	public function fetchCart($uid)
	{
		$this->db->select("courseID");
		$this->db->from("tblCart");
		$this->db->where("userID",$uid);
		return $this->db->get()->result();
	}
	public function delCart($id)
	{
		$this->db->where("userID",$id);
		return $this->db->delete("tblCart");
	}
}
?>