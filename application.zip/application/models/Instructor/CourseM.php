<?php

defined('BASEPATH') OR exit('Ille');
class CourseM extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	
	public function fetchAllCourse()
	{
		$this->db->select("c.*,s.subjectName");
		$this->db->from("tblCourse c");
		$this->db->join("tblUser u","c.userID = u.userID");
		$this->db->join("tblSubject s","s.subjectID=c.subjectID");
		$this->db->where("c.userID",$this->session->userID);
		return $this->db->get()->result();
	}

	public function fetchviewCourse($id)
	{
		$this->db->select("c.*,u.userName,s.subjectName");
		$this->db->from("tblCourse c");
		$this->db->join("tblUser u","c.userID = u.userID");
		$this->db->join("tblSubject s","s.subjectID=c.subjectID");
		$this->db->where("c.courseID",$id);	
		return $this->db->get()->result();
	}

	public function fetchReview($id)
	{
		$this->db->select("r.*,u.userName,u.image,r.courseID");
		$this->db->from("tblRatings as r");
		$this->db->join("tblCourse as c","c.courseID=r.courseID");
		$this->db->join("tblUser as u","u.userID=r.userID");
		// if($id!=null)
		$this->db->where('c.courseID',$id);
		return $this->db->get()->result();	
	}

	public function searchCourse($name)
	{
		$this->db->select("c.*,u.userName");
		$this->db->from("tblCourse c");
		if($name!=null)
		{
			$this->db->like('c.courseName', $name);
			$this->db->or_like('u.userName', $name);
		}
		$this->db->join("tblUser u","c.userID = u.userID");
		return $this->db->get()->result();
	}

	public function fetchChapter($id)
	{
		$this->db->select("c.*");
		$this->db->from("tblChapter c");
		$this->db->where("courseID",$id);
		return $this->db->get()->result();	
	}

	public function fillSubject()
	{
		return $this->db->get("tblSubject")->result();
	}

	public function addCourse($data)
	{
		$this->db->insert("tblCourse",$data);
	}

}
?>