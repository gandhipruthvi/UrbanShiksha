<?php

defined('BASEPATH') OR exit('Ille');
class ChapterM extends CI_Model
{
	public function __construct()
	{
		parent::__construct();
	}

	public function addChapter($data)
	{
		$this->db->insert("tblChapter",$data);
	}

	public function addTopics($data)
	{
		$this->db->insert("tblTopics",$data);
	}

}
?>